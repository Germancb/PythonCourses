from django.urls import path
from . import views
 
urlpatterns = [
    path('', views.form_factura, name='form_factura'),
]