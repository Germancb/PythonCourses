from django.shortcuts import render
from .forms import FormFacturaForm
from django.contrib import messages

# Create your views here.

def form_factura(request):
    form = FormFacturaForm(request.POST or None)
    if form.is_valid():
        form.save()		
        messages.success(request, 'Factura insertada correctamente.')
        form = FormFacturaForm()
    else:
        messages.error(request, 'Error al insertar factura. Revise los datos.')
    context = {'form': form }      
    return render(request, 'factura.html', context)
	