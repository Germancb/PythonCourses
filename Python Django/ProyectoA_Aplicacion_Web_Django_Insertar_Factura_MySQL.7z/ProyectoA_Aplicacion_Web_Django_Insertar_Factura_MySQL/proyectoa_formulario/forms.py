from django import forms
from .models import FormFactura

class FormFacturaForm(forms.ModelForm):
    class Meta:
        model = FormFactura
        fields = ["numero", "importe", "fecha", "cliente", "observacion"]